import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        Paquete[] v=new Paquete[7];
        ArrayList <Paquete> array=new ArrayList<>();

        Comparator<Paquete> comValor=new Comparator<Paquete>(){
            public int compare(Paquete p1,Paquete p2){
                if (p1.getValor() > p2.getValor()) return 1;
                else if (p1.getValor() < p2.getValor()) return -1;
                else return 0;
            }
        };

        Comparator<Paquete> comPeso=new Comparator<Paquete>(){
            public int compare(Paquete p1,Paquete p2){
                if (p1.getValor() > p2.getValor()) return 1;
                else if (p1.getValor() < p2.getValor()) return -1;
                else return 0;
            }
        };

        Comparator<Paquete> comValorR=new Comparator<Paquete>(){
            public int compare(Paquete p1,Paquete p2){
                if (p1.valorRelativo() < p2.valorRelativo()) return 1;
                else if (p1.valorRelativo() > p2.valorRelativo()) return -1;
                else return 0;
            }
        };

        for (int i = 0; i < v.length; i++) {
            System.out.println("Peso y valor");
            v[i]=new Paquete(s.nextDouble(),s.nextDouble(),i+1);
        }
        System.out.println(Arrays.toString(v));
        System.out.println("A:\n");
        CasoA.voraz(v,1000);
        System.out.println("B:\n");
        CasoB.voraz(v,1000);
        System.out.println("C:\n");
        CasoC.voraz(v,1000);
    }
}
